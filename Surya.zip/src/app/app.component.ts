import { Component, ViewChild, ElementRef } from "@angular/core";
import { Routes } from '@angular/router';
import { HomeComponent } from './components/home.component';
import { AboutComponent } from './components/about.component';
// import { IntlComponent } from './components/Intl.component';
// import { workComponent } from './components/WorkPlace.component';
// import { InsightComponent } from './components/Insights.component';


@Component({
  selector: 'my-app',
  templateUrl: './app.component.html'
})
export class AppComponent {  
  @ViewChild('getnav') nav:ElementRef;
  showNavbar(e:any) {
    e.target.classList.add('show');
  }
removeNavbar(e:any) {
  e.target.classList.remove('show');
}
mobileMenu(){
  console.log("hi");
  if(this.nav.nativeElement.classList.contains('show-menu')){
    this.nav.nativeElement.classList.remove("show-menu");
    console.log("remove");
  }
  else{
    console.log("add");
    this.nav.nativeElement.classList.add("show-menu");
  }
}
}
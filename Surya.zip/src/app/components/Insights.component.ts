import { Component } from "@angular/core";

@Component({
  template: `<div class="row">
  <div class="col-xs-12 col-sm-offset-1 col-sm-10">
 
</div>`
})
export class InsightComponent {
  
   
}
